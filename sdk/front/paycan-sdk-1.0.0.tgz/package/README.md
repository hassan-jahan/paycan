# PayCan Front SDK

Official JavaScript SDK for PayCan - Payment integration made simple.

[![npm version](https://badge.fury.io/js/%40paycan%2Fsdk.svg)](https://badge.fury.io/js/%40paycan%2Fsdk)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Features

✨ **Easy to Use** - Simple, really simple for developers of all skill levels
📦 **TypeScript Support** - Full type definitions for IDE autocomplete
🎯 **Framework Agnostic** - Works with React, Vue, Angular, or vanilla JavaScript with automatic token management and refresh

## Installation

```bash
npm install @paycan/sdk-front
```

Or using yarn:

```bash
yarn add @paycan/sdk
```

Or using CDN:

```html
<script src="https://unpkg.com/@paycan/sdk@latest/dist/index.js"></script>
```

## Quick Start

### 1. Set up your backend endpoint

First, create an endpoint in your backend that returns a PayCan token for your authenticated user.

**IMPORTANT**: Your backend should get the user ID from the authenticated session, **NOT** from the request body.

```javascript
// Example: Node.js/Express backend
app.post('/api/paycan/token', requireAuthMiddleware, async (req, res) => {
  // SECURITY: Get user ID from session, NOT from request body
  const userId = req.session.userId;

  // Get user details from YOUR database
  const user = await User.findById(userId);

  // Call PayCan's sync endpoint with YOUR API secret
  const response = await fetch('https://pay.yourapp.com/api/admin/users/sync', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': process.env.PAYCAN_API_SECRET // Keep this secret on backend!
    },
    body: JSON.stringify({
      user_id: user.id,
      user: {
        name: user.name,
        email: user.email
      }
    })
  });

  const data = await response.json();
  res.json({ token: data.token }); // Returns { token }
});
```

See [examples/backend-auth-endpoint.js](examples/backend-auth-endpoint.js) for more backend examples (Express, Next.js, Laravel, Django).

### 2. Initialize the SDK in your frontend

```javascript
import PayCan from '@paycan/sdk-front';

const paycan = new PayCan({
  apiUrl: 'https://pay.yourapp.com',
  debug: true // Optional: Enable debug logging
});
```

### 3. Set the user token

**Option A: Set token directly (Recommended - Most flexible)**

```javascript
// Get token from your created backend route (with authentication)
const response = await fetch('/api/paycan/token'); 
const { token } = await response.json();

// Set the token
paycan.setUserToken(token);

// Now you can make authenticated requests!
const orders = await paycan.orders.list();
```

**Option B: Use the authenticate helper (Optional - For common patterns)**

```javascript
// For cookie-based authentication
await paycan.authenticate({
  endpoint: '/api/paycan/token',
  type: 'cookie'
});

// For JWT/Bearer token authentication
await paycan.authenticate({
  endpoint: '/api/paycan/token',
  type: 'bearer',
  headers: { 'Authorization': `Bearer ${yourJWT}` }
});

// Now you can make authenticated requests!
const orders = await paycan.orders.list();
```

**That's it!** The SDK automatically:
- Stores the token securely
- Includes it in all API requests
- Refreshes the token before it expires

## API Reference

### Configuration

```typescript
interface PayCanConfig {
  apiUrl: string;          // Your PayCan instance URL
  debug?: boolean;         // Optional: Enable debug logging
  refreshThreshold?: number; // Optional: Token refresh threshold in seconds (default: 300)
  cacheTtl?: number;       // Optional: Cache TTL in seconds for subscriptions and orders (default: 60, set to 0 to disable)
}
```

**Configuration Examples:**

```javascript
// Default configuration (60s cache for subscriptions and orders)
const paycan = new PayCan({
  apiUrl: 'https://pay.yourapp.com'
});

// With custom cache TTL (2 minutes)
const paycan = new PayCan({
  apiUrl: 'https://pay.yourapp.com',
  cacheTtl: 120
});

// Disable caching (always fetch fresh)
const paycan = new PayCan({
  apiUrl: 'https://pay.yourapp.com',
  cacheTtl: 0
});
```

### Authentication

#### `setUserToken(token)` ⭐ Primary Method

Set the PayCan user token directly. This is the recommended approach.

```javascript
// Get token from your backend
const response = await fetch('/api/paycan/token');
const { token } = await response.json();

// Set the token
paycan.setUserToken(token);
```

#### `authenticate(config)` - Optional Helper

Helper method for common authentication patterns. Use this if you don't want to handle token fetching yourself.

```typescript
interface AuthenticationConfig {
  endpoint: string;         // Your backend endpoint
  type?: 'bearer' | 'cookie' | 'custom';  // Auth type (default: 'bearer')
  headers?: object;         // Optional: Custom headers
  data?: object;            // Optional: Request body data
}
```

**Examples:**

```javascript
// Cookie-based (session/cookies)
await paycan.authenticate({
  endpoint: '/api/paycan/token',
  type: 'cookie'
});

// Bearer token (JWT in Authorization header)
await paycan.authenticate({
  endpoint: '/api/paycan/token',
  type: 'bearer',
  headers: { 'Authorization': `Bearer ${yourJWT}` }
});

// Custom authentication
await paycan.authenticate({
  endpoint: '/api/paycan/token',
  type: 'custom',
  headers: { 'X-API-Key': 'your-key' }
});
```

#### `isAuthenticated()`

Check if the user has a valid token. (useful for debugging)

```javascript
if (paycan.isAuthenticated()) {
  // User has a valid token
  const orders = await paycan.orders.list();
}
```

#### `getToken()`

Get the current token (useful for debugging or storing).

```javascript
const token = paycan.getToken();
if (token) {
  localStorage.setItem('paycan_token', token);
}
```

### Orders

#### `orders.list(params?)`

Get all orders for the authenticated user with optional filtering, sorting, and pagination.

**Query Parameters:**
- `filter` - Filter orders by various criteria
  - `status` - Filter by status: `pending`, `processing`, `completed`, `failed`, `cancelled`, `refunded`
  - `gateway` - Filter by payment gateway: `stripe`, `paypal`
  - `order_number` - Filter by order number (partial match)
  - `created_after` - Filter orders created after date (YYYY-MM-DD)
  - `created_before` - Filter orders created before date (YYYY-MM-DD)
- `include` - Include related data (comma-separated): `product`, `productPrice`, `productPrice.product`, `transactions`, `fulfillments`, `subscription`
- `sort` - Sort orders (prefix with `-` for descending): `created_at`, `total`, `status`
- `per_page` - Number of items per page (1-100, default: 15)
- `page` - Page number

```javascript
// Basic usage
const response = await paycan.orders.list();
console.log(response.data); // Array of orders

// With filtering and sorting
const completedOrders = await paycan.orders.list({
  filter: {
    status: 'completed',
    created_after: '2024-01-01'
  },
  sort: '-created_at',
  per_page: 20
});

// With includes
const ordersWithProducts = await paycan.orders.list({
  include: 'productPrice.product,transactions',
  sort: '-total'
});

// Pagination
const page2 = await paycan.orders.list({ page: 2, per_page: 10 });
```

#### `orders.get(orderId, params?)`

Get a specific order by ID with optional includes.

```javascript
const { order } = await paycan.orders.get('order-123');
console.log(order.status); // 'completed'

// With includes
const { order } = await paycan.orders.get('order-123', {
  include: 'productPrice.product,transactions,fulfillments'
});
```

#### `orders.getDownloads(orderId)`

Get download links for digital products.

```javascript
const { downloads } = await paycan.orders.getDownloads('order-123');
downloads.forEach(download => {
  console.log(download.product_title);
  console.log(download.download_url);
});
```

#### `orders.getLicenses(orderId)`

Get license keys for the order.

```javascript
const { licenses } = await paycan.orders.getLicenses('order-123');
licenses.forEach(license => {
  console.log(license.product_title);
  console.log(license.license_key);
});
```

### Subscriptions

#### `subscriptions.list(params?)`

Get all subscriptions for the authenticated user with optional filtering, sorting, and pagination.

**Query Parameters:**
- `filter` - Filter subscriptions by various criteria
  - `status` - Filter by status: `active`, `trialing`, `past_due`, `canceled`, `incomplete`, `incomplete_expired`
  - `gateway` - Filter by payment gateway: `stripe`, `paypal`
  - `created_after` - Filter subscriptions created after date (YYYY-MM-DD)
  - `created_before` - Filter subscriptions created before date (YYYY-MM-DD)
- `include` - Include related data (comma-separated): `product`, `productPrice`, `productPrice.product`, `order`, `transactions`
- `sort` - Sort subscriptions (prefix with `-` for descending): `created_at`, `status`, `next_billing_date`
- `per_page` - Number of items per page (1-100, default: 15)
- `page` - Page number

```javascript
// Basic usage
const response = await paycan.subscriptions.list();
console.log(response.data); // Array of subscriptions

// Filter active subscriptions
const activeSubscriptions = await paycan.subscriptions.list({
  filter: { status: 'active' },
  include: 'productPrice.product',
  sort: '-created_at'
});

// Filter by gateway
const stripeSubscriptions = await paycan.subscriptions.list({
  filter: { gateway: 'stripe' }
});

// Date range filtering
const recentSubscriptions = await paycan.subscriptions.list({
  filter: {
    created_after: '2024-01-01',
    status: 'active'
  },
  sort: 'next_billing_date',
  per_page: 20
});
```

#### `subscriptions.listActive()`

List all active subscriptions using cache. Returns array of active subscriptions.

**⚡ Performance**: Uses intelligent caching (no API call if cache is valid).

```javascript
const activeSubscriptions = await paycan.subscriptions.listActive();
activeSubscriptions.forEach(sub => {
  console.log(sub.product_price?.product?.title);
});
```

#### `subscriptions.get(subscriptionId, params?)`

Get a specific subscription with optional includes.

```javascript
const { subscription } = await paycan.subscriptions.get('sub-123');
console.log(subscription.status); // 'active'

// With includes
const { subscription } = await paycan.subscriptions.get('sub-123', {
  include: 'productPrice.product,order,transactions'
});
```

#### `subscriptions.cancel(subscriptionId)`

Cancel a subscription.

```javascript
await paycan.subscriptions.cancel('sub-123');
```

#### `subscriptions.resume(subscriptionId)`

Resume a cancelled subscription.

```javascript
await paycan.subscriptions.resume('sub-123');
```

#### `subscriptions.change(subscriptionId, data)`

Change a subscription plan.

```javascript
await paycan.subscriptions.change('sub-123', {
  new_price_id: 'price-premium-456'
});
```

### Checkout

#### `checkout.create(data)`

Create a checkout session for purchasing products.

```javascript
const session = await paycan.checkout.create({
  product_id: 1,
  product_price_id: 1,
  gateway: 'stripe',
  billing_email: 'user@example.com', // Optional for authenticated users
  billing_name: 'John Doe',          // Optional for authenticated users
  quantity: 1                         // Optional, defaults to 1
});

// Redirect to checkout
window.location.href = session.checkout_url;
```

#### `checkout.getPortalUrl(returnUrl?)`

Get customer portal URL for managing subscriptions.

```javascript
const portal = await paycan.checkout.getPortalUrl();
window.location.href = portal.url;

// Or with a return URL
const portal = await paycan.checkout.getPortalUrl('https://yourapp.com/account');
window.location.href = portal.url;
```

### Current User

#### `paycan.me()`

Get current user information.

```javascript
const { user } = await paycan.me();
console.log(user.email);
```

## Usage Examples

### React Example

```jsx
import { useEffect, useState } from 'react';
import PayCan from '@paycan/sdk';

const paycan = new PayCan({
  apiUrl: 'https://pay.yourapp.com'
});

function App() {
  const [isReady, setIsReady] = useState(false);

  // Set token on app load
  useEffect(() => {
    async function initPayCan() {
      try {
        const response = await fetch('/api/paycan/token');
        const { token } = await response.json();
        paycan.setUserToken(token);
        setIsReady(true);
      } catch (error) {
        console.error('Failed to initialize PayCan:', error);
      }
    }
    initPayCan();
  }, []);

  if (!isReady) return <div>Loading...</div>;

  return <OrdersList />;
}

function OrdersList() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadOrders() {
      try {
        const response = await paycan.orders.list();
        setOrders(response.data);
      } catch (error) {
        console.error('Failed to load orders:', error);
      } finally {
        setLoading(false);
      }
    }
    loadOrders();
  }, []);

  if (loading) return <div>Loading orders...</div>;

  return (
    <div>
      <h2>Your Orders</h2>
      {orders.map(order => (
        <div key={order.id}>
          <h3>Order #{order.order_number}</h3>
          <p>Status: {order.status}</p>
          <p>Total: ${order.total}</p>
        </div>
      ))}
    </div>
  );
}
```

See [examples/react-example.tsx](examples/react-example.tsx) for a complete React integration with Context, hooks, and components.

### Vue Example

```vue
<template>
  <div v-if="isReady">
    <h2>Your Subscriptions</h2>
    <div v-for="sub in subscriptions" :key="sub.id">
      <h3>{{ sub.product_price?.product?.title }}</h3>
      <p>Status: {{ sub.status }}</p>
      <button @click="cancelSubscription(sub.id)">Cancel</button>
    </div>
  </div>
  <div v-else>Loading...</div>
</template>

<script>
import PayCan from '@paycan/sdk';

const paycan = new PayCan({
  apiUrl: 'https://pay.yourapp.com'
});

export default {
  data() {
    return {
      isReady: false,
      subscriptions: []
    };
  },
  async created() {
    // Set token on app load
    try {
      const response = await fetch('/api/paycan/token');
      const { token } = await response.json();
      paycan.setUserToken(token);
      this.isReady = true;

      // Load subscriptions
      const subsResponse = await paycan.subscriptions.list();
      this.subscriptions = subsResponse.data;
    } catch (error) {
      console.error('Failed to initialize:', error);
    }
  },
  methods: {
    async cancelSubscription(id) {
      await paycan.subscriptions.cancel(id);
      // Refresh list
      const response = await paycan.subscriptions.list();
      this.subscriptions = response.data;
    }
  }
};
</script>
```

### Vanilla JavaScript Example

```html
<!DOCTYPE html>
<html
<head>
  <title>PayCan Example</title>
  <script src="https://unpkg.com/@paycan/sdk@latest/dist/index.js"></script>
</head>
<body>
  <div id="app">
    <button onclick="createCheckout()">Buy Premium Plan</button>
  </div>

  <script>
    const paycan = new PayCan({
      apiUrl: 'https://pay.yourapp.com'
    });

    // Get token on page load
    (async function() {
      try {
        // Get PayCan token from your backend
        const response = await fetch('/api/paycan/token');
        const { token } = await response.json();

        // Set the token
        paycan.setUserToken(token);
        console.log('Authenticated!');
      } catch (error) {
        console.error('Authentication failed:', error);
      }
    })();

    async function createCheckout() {
      const session = await paycan.checkout.create({
        product_id: 1,
        product_price_id: 1,
        gateway: 'stripe'
      });

      window.location.href = session.checkout_url;
    }
  </script>
</body>
</html>
```

## Error Handling

The SDK throws errors that you should handle:

```javascript
try {
  // Get and set token
  const response = await fetch('/api/paycan/token');
  const { token } = await response.json();
  paycan.setUserToken(token);

  // Make API calls
  const orders = await paycan.orders.list();
} catch (error) {
  if (error.status === 401) {
    console.error('Authentication failed - user not logged in');
    // Redirect to login page
  } else if (error.status === 403) {
    console.error('Access denied');
  } else {
    console.error('Error:', error.message);
    if (error.errors) {
      // Validation errors
      console.error('Validation errors:', error.errors);
    }
  }
}
```

## Security Best Practices

1. **Never expose your API secret key in frontend code** - Always keep it on the backend
2. **Get user ID from session, NEVER from request body** - Your backend should always get the user ID from the authenticated session (req.user, req.session, JWT token, etc.), never from the request body sent by the frontend
3. **Use HTTPS** - Always use HTTPS in production
4. **Implement rate limiting** - Protect your auth endpoint from abuse
5. **Require authentication middleware** - Ensure your auth endpoint is protected by your authentication middleware
6. **Sanitize user input** - Validate and sanitize all data before sending to PayCan

## Token Management

The SDK automatically handles token refresh. Tokens are refreshed 5 minutes before expiry by default.

You can customize the refresh threshold:

```javascript
const paycan = new PayCan({
  apiUrl: 'https://pay.yourapp.com',
  refreshThreshold: 600 // Refresh 10 minutes before expiry (in seconds)
});

// Set token
paycan.setUserToken(yourToken);
```

## TypeScript Support

The SDK is written in TypeScript and includes full type definitions:

```typescript
import PayCan, { Order, Subscription, type PayCanConfig } from '@paycan/sdk';

const config: PayCanConfig = {
  apiUrl: 'https://pay.yourapp.com',
  debug: true,
  refreshThreshold: 300
};

const paycan = new PayCan(config);

// Set token
const response = await fetch('/api/paycan/token');
const { token } = await response.json();
paycan.setUserToken(token);

// Types are automatically inferred
const orders: Order[] = (await paycan.orders.list()).data;
```

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

MIT

## Support

- 📧 Email: support@paycan.com
- 📚 Documentation: https://paycan.com/docs
- 🐛 Issues: https://github.com/paycan/sdk/issues

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

### Checkout Modal (Web Component)

The SDK includes a built-in checkout modal web component that provides a complete, framework-agnostic checkout experience. The modal handles price selection, payment gateway selection, guest checkout, and more.

#### `openCheckoutModal(productId, options)`

Open a checkout modal for a product with multiple prices.

```javascript
// Basic usage - opens modal with light theme
paycan.openCheckoutModal(123);

// With custom options
paycan.openCheckoutModal(123, {
  theme: 'dark', // 'light' or 'dark'
  onSuccess: (checkoutUrl) => {
    // Redirect or handle checkout URL
    window.location.href = checkoutUrl;
  },
  onCancel: () => {
    console.log('User cancelled checkout');
  },
  onError: (error) => {
    console.error('Checkout error:', error);
  }
});
```

#### `openCheckoutModalPrice(priceId, options)`

Open a checkout modal for a specific price.

```javascript
// Basic usage
paycan.openCheckoutModalPrice(456);

// With callbacks
paycan.openCheckoutModalPrice(456, {
  theme: 'light',
  onSuccess: (checkoutUrl) => {
    window.location.href = checkoutUrl;
  }
});
```

**Modal Features:**

- **Automatic Price Selection UI**
  - Radio buttons for < 3 prices
  - Dropdown select for ≥ 3 prices
  - Live preview updates when price changes

- **Dynamic Payment Gateways**
  - Shows available gateways from preview API
  - Updates when different price is selected
  - Visual gateway cards with descriptions

- **Guest Checkout**
  - Email field appears for unauthenticated users
  - Email validation before checkout
  - Seamless authenticated user flow

- **Responsive Design**
  - Mobile, tablet, and desktop optimized
  - Clean, modern, minimal interface
  - Smooth animations and transitions

- **Theme Support**
  - Light and dark mode themes
  - Consistent with your brand

- **Security**
  - Input sanitization and XSS prevention
  - Secure checkout flow
  - No sensitive data storage

**Options:**

```typescript
interface CheckoutModalOptions {
  productId?: number;      // Product ID to checkout
  priceId?: number;        // Specific price ID
  theme?: 'light' | 'dark'; // Theme (default: 'light')
  onSuccess?: (checkoutUrl: string) => void;  // Success callback
  onCancel?: () => void;   // Cancel callback
  onError?: (error: Error) => void;  // Error callback
}
```

### Checkout Preview

Get a full preview of product prices, tax, and available payment methods for the selected product/price. This is useful to render a checkout page before creating an order.

```typescript
// Example: preview checkout options and totals
const preview = await paycan.checkout.preview({
  product_price_id: 123,
  quantity: 2,
  billing_country: 'US',
  billing_state: 'CA',
});

// Selected price breakdown
console.log(preview.selected_price?.final_price, preview.selected_price?.tax_amount);

// Available payment methods for this product/price
preview.payment_methods.forEach(pm => {
  console.log(pm.key, pm.name, pm.supports_subscriptions);
});
```

Response shape:

- `product`: Basic product info
- `selected_price`: Detailed price breakdown including `subtotal`, `tax_amount`, `final_price`
- `prices`: List of active prices for the product with the same breakdown
- `quantity`: Quantity used for calculation
- `tax`: Applied tax rate and region context
- `payment_methods`: Enabled gateways compatible with product/price (from `PaymentGatewayRegistry`)

